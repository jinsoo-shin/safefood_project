﻿package com.ssafy.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ssafy.model.dto.Food;
import com.ssafy.model.dto.FoodPageBean;
import com.ssafy.model.dto.User;
import com.ssafy.model.repository.UserDaoImple;
import com.ssafy.model.service.FoodService;
import com.ssafy.model.service.UserService;

@Controller
public class MainController {

	@Autowired
	FoodService foodService;

//	@RequestMapping("/errorpage")
//	public String error(Model model) {
//		return "errorpage";
//	}
	@RequestMapping("/")
	public String mainIndex(Model model) {
		return "index";
	}
	@RequestMapping("/qna")
	public String qnaIndex(Model model) {
		return "qna";
	}

	@GetMapping("/index") // 검색 용
	public String index(Model model) {
		List<Food> list = foodService.selectAll();
		for (int i = 0; i < list.size(); i++) {
			List<String> allergy = foodService.selectAllergy(list.get(i));
			list.get(i).setAllergy(allergy);
		}
		model.addAttribute("foodList", list);
		return "index";
	}

	@GetMapping("/foodinfo") // 상품정보페이지
	public String foodinfo(Model model) {
		List<Food> list = foodService.selectAll();
		for (int i = 0; i < list.size(); i++) {
			List<String> allergy = foodService.selectAllergy(list.get(i));
			list.get(i).setAllergy(allergy);
		}
		model.addAttribute("foodList", list);
		return "food_info";
	}

	@GetMapping("/indexsearch") // 검색 용
	public String indexsearch(Model model, String key, String word) {
		System.out.println("키" + key + " word" + word);
		List<Food> list = foodService.selectFoodBean(new FoodPageBean(key, word));
		for (int i = 0; i < list.size(); i++) {
			List<String> allergy = foodService.selectAllergy(list.get(i));
			list.get(i).setAllergy(allergy);
		}
		System.out.println("갸아아악" + list);
		model.addAttribute("foodList", list);
		return "index";
	}

	@GetMapping("/infosearch") // 검색 용
	public String infosearch(Model model, String key, String word) {
		List<Food> list = foodService.selectFoodBean(new FoodPageBean(key, word));
		for (int i = 0; i < list.size(); i++) {
			List<String> allergy = foodService.selectAllergy(list.get(i));
			list.get(i).setAllergy(allergy);
		}
		model.addAttribute("foodList", list);
		return "food_info";
	}

	@GetMapping("/detail") // 상세페이지
	public String detail(Model model, String code) {
		Food food = foodService.select(code);
		food.setAllergy(foodService.selectAllergy(food));
		model.addAttribute("food", food);
		return "food_detail";
	}

	@GetMapping("/eat") // 섭취정보추가
	public String eat(Model model, String code, HttpSession session, HttpServletRequest request,
			RedirectAttributes redir) {
		User loginUser = (User) session.getAttribute("loginUser");
		if (loginUser == null) {
			redir.addFlashAttribute("alarm", "로그인 해주세용");
			String referer = request.getHeader("Referer");
			return "redirect:" + referer;
		} else {
			List<String> result = foodService.selectIsUserEat(loginUser, code);
			if (result.size() == 0) {
				foodService.insertUserEat(code, loginUser);
				redir.addFlashAttribute("alarm", "추가 성공성공");
				String referer = request.getHeader("Referer");
				return "redirect:" + referer;
			} else {
				redir.addFlashAttribute("alarm", "이미 들어가있어용");
				String referer = request.getHeader("Referer");
				return "redirect:" + referer;
			}
		}
	}

	@GetMapping("/userEat") // 섭취정보
	public String userEat(Model model, HttpSession session, RedirectAttributes redir, HttpServletRequest request) {
		User loginUser = (User) session.getAttribute("loginUser");
		if (loginUser == null) {
			redir.addFlashAttribute("alarm", "로그인 후 이용가능 페이지!!!!!");
			String referer = request.getHeader("Referer");
			return "redirect:" + referer;
		} else {
			List<String> foodCode = foodService.selectUserEat(loginUser);
			System.out.println("코드코드" + foodCode);
			List<Food> food = new ArrayList<>();
			for (int i = 0; i < foodCode.size(); i++) {
				Food tmp = foodService.select(foodCode.get(i));
				List<String> allergy = foodService.selectAllergy(tmp);
				tmp.setAllergy(allergy);
				food.add(tmp);
			}

			System.out.println("먹은거" + food);
			model.addAttribute("eatfoods", food);
			return "userEatInfo";
		}

	}

	@GetMapping("/deleteEat") // 섭취정보삭제
	public String deleteEat(Model model, String code, HttpSession session, RedirectAttributes redir,
			HttpServletRequest request) {
		User loginUser = (User) session.getAttribute("loginUser");
		foodService.deleteUserEat(code, loginUser);
		redir.addFlashAttribute("alarm", "삭제되었습니당");
		String referer = request.getHeader("Referer");
		return "redirect:" + referer;
	}

///////////////////////////////////////////////////////////////
	@Autowired
	UserService service;
	@Autowired
	UserDaoImple dao;

	@GetMapping("/register") // 회원가입누르면 가는 페이지
	public String registerGet(Model model) {
		return "register";
	}

	@PostMapping("/register")
	// 회원가입
	public String login(Model model, User user, RedirectAttributes redir) {
		int result = dao.insert(user);
		int result2 = dao.insertAllergy(user);
		if (result != -1 && result2 != -1) {
			redir.addFlashAttribute("alarm", "회원가입을 축하합니다.");
			return "redirect:/index";
		} else {
			return "redirect:/register";
		}
	}

	// 회원인지아닌지
	@GetMapping("/login")
	public String doLogin(Model model, String username, String password, HttpSession session,
			RedirectAttributes redir) {
		User result = service.ulogin(username, password);
		if (result != null) {
			result.setAllergy(dao.selectAllergy(username));

			session.setAttribute("loginUser", result);
			redir.addFlashAttribute("alarm", result.getName() + "님 로그인 되었습니다.");
			return "redirect:/index";
		} else {
			redir.addFlashAttribute("alarm", "회원정보가 없습니다.");
			return "redirect:/index";
		}

	}

	// 회원정보누르면 그 페이지
	@GetMapping("/mypage")
	public String doUserUpdate(Model model) {
		return "mypage";
	}

	// 회원정보업데이트
	@PostMapping("/mypage")
	public String userUpdate(Model model, User user, HttpSession session, RedirectAttributes redir) {
		dao.deleteAllergy(user.getId());

		int result = dao.update(user);
		int result2 = dao.updateAllergy(user);
		if (result != -1 && result2 != -1) {
			User tmp = dao.select(user.getId());
			tmp.setAllergy(dao.selectAllergy(user.getId()));
			session.setAttribute("loginUser", tmp);
			redir.addFlashAttribute("alarm", "수정되었습니다.");
			return "redirect:/index";
		} else {
			return "redirect:/mypage";
		}
	}

	// 탈퇴하기
	@GetMapping("/bye")
	public String doBye(Model model, HttpSession session, RedirectAttributes redir) {
		User user = (User) session.getAttribute("loginUser");
		foodService.deleteUserEatAll(user);
		dao.deleteAllergy(user.getId());
		
		int result = dao.delete(user.getId());
		if (result != -1) {
			session.invalidate();
			redir.addFlashAttribute("alarm", "흑흑ㅠㅠ 다음에 또 봐요.");
			return "redirect:/index";
		} else {
			return "redirect:/mypage";

		}
	}

	@GetMapping("logout")
	public String logout(Model model, HttpSession session, RedirectAttributes redir) {
		redir.addFlashAttribute("alarm", "로그아웃되었습니다.");
		session.invalidate();
		return "redirect:/index";
	}

	// 비밀번호찾기페이지가기
	@GetMapping("/findpass")
	public String findGo(Model model, String id, String phone, HttpSession session) {
		return "findpass";

	}

	// 비밀번호찾기
	@GetMapping("/getpass")
	public String doFine(Model model, String id, String phone, HttpSession session) {
		User user = dao.select(id);
		String pass = user.getPassword();
		session.setAttribute("pass", pass);
		return "findpass";

	}
}
